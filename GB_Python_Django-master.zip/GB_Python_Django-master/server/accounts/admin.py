from django.contrib import admin
from .models import AccountUser


admin.site.register(AccountUser)
